#nullable disable
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.Admin
{
    public class RequestApprovalForm : Form
    {
        private DataGridView dgvPending;
        private Button btnApprove, btnReject;
        private int selectedRequestId = -1;
        private string connectionString;

        public RequestApprovalForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "Request Approval";
            this.Size = new Size(900, 550);
            this.StartPosition = FormStartPosition.CenterScreen;

            dgvPending = new DataGridView
            {
                Location = new Point(20, 20),
                Size = new Size(850, 400),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.CellSelect
            };
            dgvPending.CellClick += DgvPending_CellClick;

            btnApprove = new Button { Text = "Approve", Location = new Point(300, 450), Size = new Size(100, 40) };
            btnApprove.Click += BtnApprove_Click;
            btnReject = new Button { Text = "Reject", Location = new Point(500, 450), Size = new Size(100, 40) };
            btnReject.Click += BtnReject_Click;

            this.Controls.Add(dgvPending);
            this.Controls.Add(btnApprove);
            this.Controls.Add(btnReject);

            LoadPendingRequests();
        }

        private void LoadPendingRequests()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT * FROM BloodRequests WHERE Status = 'Pending' ORDER BY RequestDate";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvPending.DataSource = dt;
            }
        }

        private void DgvPending_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedRequestId = Convert.ToInt32(dgvPending.Rows[e.RowIndex].Cells["RequestID"].Value);
            }
        }

        private void BtnApprove_Click(object sender, EventArgs e)
        {
            if (selectedRequestId == -1) { MessageBox.Show("Select a request to approve."); return; }

            string bloodGroup = "";
            int units = 0;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string getReq = "SELECT BloodGroup, Units FROM BloodRequests WHERE RequestID = @id";
                using (SqlCommand cmd = new SqlCommand(getReq, con))
                {
                    cmd.Parameters.AddWithValue("@id", selectedRequestId);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bloodGroup = reader["BloodGroup"].ToString();
                            units = Convert.ToInt32(reader["Units"]);
                        }
                        else { MessageBox.Show("Request not found."); return; }
                    }
                }
            }

            int available = 0;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string checkInv = "SELECT AvailableUnits FROM Inventory WHERE BloodGroup = @bg";
                using (SqlCommand cmd = new SqlCommand(checkInv, con))
                {
                    cmd.Parameters.AddWithValue("@bg", bloodGroup);
                    object result = cmd.ExecuteScalar();
                    if (result != null) available = Convert.ToInt32(result);
                }
            }

            if (available < units)
            {
                MessageBox.Show($"Insufficient inventory for {bloodGroup}. Available: {available}, Requested: {units}.",
                    "Stock Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (var transaction = con.BeginTransaction())
                    {
                        string updateReq = "UPDATE BloodRequests SET Status = 'Approved', ApprovalDate = GETDATE() WHERE RequestID = @id";
                        using (SqlCommand cmd = new SqlCommand(updateReq, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@id", selectedRequestId);
                            cmd.ExecuteNonQuery();
                        }
                        string updateInv = "UPDATE Inventory SET AvailableUnits = AvailableUnits - @units, LastUpdated = GETDATE() WHERE BloodGroup = @bg";
                        using (SqlCommand cmd = new SqlCommand(updateInv, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@units", units);
                            cmd.Parameters.AddWithValue("@bg", bloodGroup);
                            cmd.ExecuteNonQuery();
                        }
                        transaction.Commit();
                    }
                }
                LoadPendingRequests();
                selectedRequestId = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error approving request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnReject_Click(object sender, EventArgs e)
        {
            if (selectedRequestId == -1) { MessageBox.Show("Select a request to reject."); return; }
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "UPDATE BloodRequests SET Status = 'Rejected', ApprovalDate = GETDATE() WHERE RequestID = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", selectedRequestId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadPendingRequests();
            selectedRequestId = -1;
        }
    }
}

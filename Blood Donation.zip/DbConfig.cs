#nullable disable
namespace BloodBankSystem.Helpers
{
    /// <summary>
    /// Central place to store and retrieve the database connection string.
    /// Change the value here to point to a different SQL Server instance.
    /// </summary>
    public static class DbConfig
    {
        public const string ConnectionString =
            "Data Source=DESKTOP-TDLOT1L\\SQLEXPRESS;" +
            "Initial Catalog=BloodBankDB;" +
            "Integrated Security=True;" +
            "Trust Server Certificate=True";
    }
}

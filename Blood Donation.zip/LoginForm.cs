#nullable disable
using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using BloodBankSystem.Helpers;
using BloodBankSystem.Forms.Admin;
using BloodBankSystem.Forms.User;

namespace BloodBankSystem
{
    public class LoginForm : Form
    {
        private TextBox txtUsername, txtPassword;
        private Button btnLogin;
        private ComboBox cboRole;
        private readonly string connectionString = DbConfig.ConnectionString;

        public LoginForm()
        {
            this.Text = "Blood Bank System - Login";
            this.Size = new Size(400, 320);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            Label lblTitle = new Label
            {
                Text = "Blood Bank System",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(80, 20),
                Size = new Size(240, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label lblRole = new Label { Text = "Role:", Location = new Point(50, 70), Size = new Size(80, 25), TextAlign = ContentAlignment.MiddleRight };
            cboRole = new ComboBox { Location = new Point(140, 70), Size = new Size(180, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            cboRole.Items.AddRange(new object[] { "Admin", "User" });
            cboRole.SelectedIndex = 0;

            Label lblUsername = new Label { Text = "Username:", Location = new Point(50, 110), Size = new Size(80, 25), TextAlign = ContentAlignment.MiddleRight };
            txtUsername = new TextBox { Location = new Point(140, 110), Size = new Size(180, 25) };

            Label lblPassword = new Label { Text = "Password:", Location = new Point(50, 150), Size = new Size(80, 25), TextAlign = ContentAlignment.MiddleRight };
            txtPassword = new TextBox { Location = new Point(140, 150), Size = new Size(180, 25), PasswordChar = '*' };

            btnLogin = new Button { Text = "Login", Location = new Point(150, 200), Size = new Size(100, 35) };
            btnLogin.Click += BtnLogin_Click;

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblRole);
            this.Controls.Add(cboRole);
            this.Controls.Add(lblUsername);
            this.Controls.Add(txtUsername);
            this.Controls.Add(lblPassword);
            this.Controls.Add(txtPassword);
            this.Controls.Add(btnLogin);
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text.Trim();
            string pass = txtPassword.Text.Trim();
            string role = cboRole.SelectedItem.ToString();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Please enter username and password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "SELECT UserID, Username FROM Users WHERE Username=@user AND Password=@pass AND Role=@role";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@user", user);
                        cmd.Parameters.AddWithValue("@pass", pass);
                        cmd.Parameters.AddWithValue("@role", role);
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string username = reader.GetString(1);
                                if (role == "Admin")
                                {
                                    DashboardForm dashboard = new DashboardForm(connectionString);
                                    dashboard.Show();
                                }
                                else
                                {
                                    UserPortalForm userPortal = new UserPortalForm(username, connectionString);
                                    userPortal.Show();
                                }
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Invalid username, password, or role.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

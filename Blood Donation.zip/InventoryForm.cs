#nullable disable
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.Admin
{
    public class InventoryForm : Form
    {
        private DataGridView dgvInventory;
        private TextBox txtBloodGroup, txtUnits;
        private Button btnUpdate;
        private string connectionString;

        public InventoryForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "Blood Inventory";
            this.Size = new Size(700, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            dgvInventory = new DataGridView
            {
                Location = new Point(20, 20),
                Size = new Size(400, 400),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.CellSelect
            };
            dgvInventory.CellClick += DgvInventory_CellClick;

            Label lblBG = new Label { Text = "Blood Group:", Location = new Point(450, 30), Size = new Size(100, 25) };
            txtBloodGroup = new TextBox { Location = new Point(560, 30), Size = new Size(100, 25), ReadOnly = true };
            Label lblUnits = new Label { Text = "Available Units:", Location = new Point(450, 70), Size = new Size(100, 25) };
            txtUnits = new TextBox { Location = new Point(560, 70), Size = new Size(100, 25) };
            btnUpdate = new Button { Text = "Update", Location = new Point(450, 120), Size = new Size(120, 35) };
            btnUpdate.Click += BtnUpdate_Click;

            this.Controls.Add(dgvInventory);
            this.Controls.Add(lblBG); this.Controls.Add(txtBloodGroup);
            this.Controls.Add(lblUnits); this.Controls.Add(txtUnits);
            this.Controls.Add(btnUpdate);

            LoadInventory();
        }

        private void LoadInventory()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT BloodGroup, AvailableUnits FROM Inventory ORDER BY BloodGroup";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvInventory.DataSource = dt;
            }
        }

        private void DgvInventory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtBloodGroup.Text = dgvInventory.Rows[e.RowIndex].Cells["BloodGroup"].Value.ToString();
                txtUnits.Text = dgvInventory.Rows[e.RowIndex].Cells["AvailableUnits"].Value.ToString();
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBloodGroup.Text) || !int.TryParse(txtUnits.Text, out int units) || units < 0)
            {
                MessageBox.Show("Enter a valid non-negative number of units.");
                return;
            }
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "UPDATE Inventory SET AvailableUnits = @units, LastUpdated = GETDATE() WHERE BloodGroup = @bg";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@units", units);
                    cmd.Parameters.AddWithValue("@bg", txtBloodGroup.Text);
                    if (cmd.ExecuteNonQuery() == 0)
                    {
                        query = "INSERT INTO Inventory (BloodGroup, AvailableUnits, LastUpdated) VALUES (@bg, @units, GETDATE())";
                        using (SqlCommand cmd2 = new SqlCommand(query, con))
                        {
                            cmd2.Parameters.AddWithValue("@bg", txtBloodGroup.Text);
                            cmd2.Parameters.AddWithValue("@units", units);
                            cmd2.ExecuteNonQuery();
                        }
                    }
                }
            }
            LoadInventory();
        }
    }
}

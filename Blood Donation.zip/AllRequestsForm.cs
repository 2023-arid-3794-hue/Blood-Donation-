#nullable disable
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.Admin
{
    public class AllRequestsForm : Form
    {
        private DataGridView dgvRequests;
        private string connectionString;

        public AllRequestsForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "All Blood Requests";
            this.Size = new System.Drawing.Size(900, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            dgvRequests = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            this.Controls.Add(dgvRequests);
            LoadRequests();
        }

        private void LoadRequests()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT * FROM BloodRequests ORDER BY RequestDate DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvRequests.DataSource = dt;
            }
        }
    }
}

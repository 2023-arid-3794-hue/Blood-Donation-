#nullable disable
using System.Drawing;
using System.Windows.Forms;

namespace BloodBankSystem.Forms.Admin
{
    public class DashboardForm : Form
    {
        private Button btnDonors, btnDonations, btnInventory, btnRequests, btnApproval, btnLogout;
        private string connectionString;

        public DashboardForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "Blood Bank System - Admin Dashboard";
            this.Size = new Size(400, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            btnDonors = new Button { Text = "Manage Donors", Location = new Point(50, 50), Size = new Size(280, 40) };
            btnDonors.Click += (s, e) => new DonorsForm(connectionString).Show();

            btnDonations = new Button { Text = "Donation Records", Location = new Point(50, 110), Size = new Size(280, 40) };
            btnDonations.Click += (s, e) => new DonationRecordsForm(connectionString).Show();

            btnInventory = new Button { Text = "Blood Inventory", Location = new Point(50, 170), Size = new Size(280, 40) };
            btnInventory.Click += (s, e) => new InventoryForm(connectionString).Show();

            btnRequests = new Button { Text = "All Blood Requests", Location = new Point(50, 230), Size = new Size(280, 40) };
            btnRequests.Click += (s, e) => new AllRequestsForm(connectionString).Show();

            btnApproval = new Button { Text = "Request Approval", Location = new Point(50, 290), Size = new Size(280, 40) };
            btnApproval.Click += (s, e) => new RequestApprovalForm(connectionString).Show();

            btnLogout = new Button { Text = "Logout", Location = new Point(280, 420), Size = new Size(80, 30) };
            btnLogout.Click += (s, e) => { this.Close(); Application.Restart(); };

            this.Controls.Add(btnDonors);
            this.Controls.Add(btnDonations);
            this.Controls.Add(btnInventory);
            this.Controls.Add(btnRequests);
            this.Controls.Add(btnApproval);
            this.Controls.Add(btnLogout);
        }
    }
}

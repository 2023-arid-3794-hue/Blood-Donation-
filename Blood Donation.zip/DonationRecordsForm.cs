#nullable disable
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.Admin
{
    public class DonationRecordsForm : Form
    {
        private DataGridView dgvDonations;
        private string connectionString;

        public DonationRecordsForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "All Donation Records";
            this.Size = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;

            dgvDonations = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            this.Controls.Add(dgvDonations);
            LoadDonations();
        }

        private void LoadDonations()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"SELECT d.DonationID, dr.FullName AS Donor, d.DonationDate, d.BloodGroup, d.Units 
                                 FROM Donations d JOIN Donors dr ON d.DonorID = dr.DonorID 
                                 ORDER BY d.DonationDate DESC";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvDonations.DataSource = dt;
            }
        }
    }
}

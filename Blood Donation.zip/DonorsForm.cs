#nullable disable
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.Admin
{
    public class DonorsForm : Form
    {
        private DataGridView dgvDonors;
        private TextBox txtName, txtBloodGroup, txtDOB, txtGender, txtPhone, txtEmail, txtAddress;
        private Button btnAdd, btnUpdate, btnDelete;
        private int selectedDonorId = -1;
        private string connectionString;

        public DonorsForm(string connStr)
        {
            connectionString = connStr;
            this.Text = "Donor Management";
            this.Size = new Size(900, 550);
            this.StartPosition = FormStartPosition.CenterScreen;

            dgvDonors = new DataGridView
            {
                Location = new Point(20, 20),
                Size = new Size(500, 450),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.CellSelect
            };
            dgvDonors.CellClick += DgvDonors_CellClick;

            int x = 540;
            Label lblName = new Label { Text = "Full Name:", Location = new Point(x, 30), Size = new Size(80, 25) };
            txtName = new TextBox { Location = new Point(x + 90, 30), Size = new Size(200, 25) };
            Label lblBloodGroup = new Label { Text = "Blood Group:", Location = new Point(x, 70), Size = new Size(80, 25) };
            txtBloodGroup = new TextBox { Location = new Point(x + 90, 70), Size = new Size(100, 25) };
            Label lblDOB = new Label { Text = "Date of Birth:", Location = new Point(x, 110), Size = new Size(80, 25) };
            txtDOB = new TextBox { Location = new Point(x + 90, 110), Size = new Size(120, 25) };
            Label lblGender = new Label { Text = "Gender:", Location = new Point(x, 150), Size = new Size(80, 25) };
            txtGender = new TextBox { Location = new Point(x + 90, 150), Size = new Size(100, 25) };
            Label lblPhone = new Label { Text = "Phone:", Location = new Point(x, 190), Size = new Size(80, 25) };
            txtPhone = new TextBox { Location = new Point(x + 90, 190), Size = new Size(150, 25) };
            Label lblEmail = new Label { Text = "Email:", Location = new Point(x, 230), Size = new Size(80, 25) };
            txtEmail = new TextBox { Location = new Point(x + 90, 230), Size = new Size(200, 25) };
            Label lblAddress = new Label { Text = "Address:", Location = new Point(x, 270), Size = new Size(80, 25) };
            txtAddress = new TextBox { Location = new Point(x + 90, 270), Size = new Size(200, 60), Multiline = true };

            btnAdd = new Button { Text = "Add", Location = new Point(x, 360), Size = new Size(80, 30) };
            btnAdd.Click += BtnAdd_Click;
            btnUpdate = new Button { Text = "Update", Location = new Point(x + 100, 360), Size = new Size(80, 30) };
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete = new Button { Text = "Delete", Location = new Point(x + 200, 360), Size = new Size(80, 30) };
            btnDelete.Click += BtnDelete_Click;

            this.Controls.Add(dgvDonors);
            this.Controls.Add(lblName); this.Controls.Add(txtName);
            this.Controls.Add(lblBloodGroup); this.Controls.Add(txtBloodGroup);
            this.Controls.Add(lblDOB); this.Controls.Add(txtDOB);
            this.Controls.Add(lblGender); this.Controls.Add(txtGender);
            this.Controls.Add(lblPhone); this.Controls.Add(txtPhone);
            this.Controls.Add(lblEmail); this.Controls.Add(txtEmail);
            this.Controls.Add(lblAddress); this.Controls.Add(txtAddress);
            this.Controls.Add(btnAdd); this.Controls.Add(btnUpdate); this.Controls.Add(btnDelete);

            LoadDonors();
        }

        private void LoadDonors()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT DonorID, FullName, BloodGroup, DateOfBirth, Gender, Phone, Email, Address FROM Donors ORDER BY DonorID";
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvDonors.DataSource = dt;
            }
        }

        private void DgvDonors_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedDonorId = Convert.ToInt32(dgvDonors.Rows[e.RowIndex].Cells["DonorID"].Value);
                txtName.Text = dgvDonors.Rows[e.RowIndex].Cells["FullName"].Value.ToString();
                txtBloodGroup.Text = dgvDonors.Rows[e.RowIndex].Cells["BloodGroup"].Value.ToString();
                txtDOB.Text = Convert.ToDateTime(dgvDonors.Rows[e.RowIndex].Cells["DateOfBirth"].Value).ToString("yyyy-MM-dd");
                txtGender.Text = dgvDonors.Rows[e.RowIndex].Cells["Gender"].Value.ToString();
                txtPhone.Text = dgvDonors.Rows[e.RowIndex].Cells["Phone"].Value.ToString();
                txtEmail.Text = dgvDonors.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                txtAddress.Text = dgvDonors.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtBloodGroup.Text))
            { MessageBox.Show("Name and Blood Group required."); return; }
            if (!DateTime.TryParse(txtDOB.Text, out DateTime dob)) dob = DateTime.Now.AddYears(-20);
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"INSERT INTO Donors (FullName, BloodGroup, DateOfBirth, Gender, Phone, Email, Address, RegistrationDate) 
                                 VALUES (@name, @bg, @dob, @gender, @phone, @email, @address, GETDATE())";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@bg", txtBloodGroup.Text.Trim());
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@gender", txtGender.Text.Trim());
                    cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }
            LoadDonors();
            ClearFields();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedDonorId == -1) { MessageBox.Show("Select a donor to update."); return; }
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"UPDATE Donors SET FullName=@name, BloodGroup=@bg, DateOfBirth=@dob, Gender=@gender, 
                                 Phone=@phone, Email=@email, Address=@address WHERE DonorID=@id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@bg", txtBloodGroup.Text.Trim());
                    cmd.Parameters.AddWithValue("@dob", DateTime.Parse(txtDOB.Text));
                    cmd.Parameters.AddWithValue("@gender", txtGender.Text.Trim());
                    cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", selectedDonorId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadDonors();
            ClearFields();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (selectedDonorId == -1) { MessageBox.Show("Select a donor to delete."); return; }
            if (DialogResult.Yes == MessageBox.Show("Delete this donor? All donation records will also be deleted.", "Confirm", MessageBoxButtons.YesNo))
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = "DELETE FROM Donors WHERE DonorID=@id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", selectedDonorId);
                        cmd.ExecuteNonQuery();
                    }
                }
                LoadDonors();
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtName.Text = txtBloodGroup.Text = txtDOB.Text = txtGender.Text =
                txtPhone.Text = txtEmail.Text = txtAddress.Text = "";
            selectedDonorId = -1;
        }
    }
}

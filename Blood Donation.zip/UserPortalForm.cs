#nullable disable
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace BloodBankSystem.Forms.User
{
    public class UserPortalForm : Form
    {
        private string username;
        private string connectionString;
        private int donorId = -1;

        // Profile panel controls
        private Panel pnlProfile;
        private TextBox txtName;
        private ComboBox cboBloodGroup, cboGender;
        private TextBox txtAge, txtPhone, txtAddress;
        private Button btnRegister, btnUpdateProfile;

        // Donation panel controls
        private Panel pnlDonation;
        private TextBox txtDonationDate, txtDonationUnits;
        private Button btnSubmitDonation;
        private DataGridView dgvDonationHistory;

        // Request panel controls
        private Panel pnlRequest;
        private TextBox txtPatientName, txtRequestUnits, txtHospitalName, txtRequestDate;
        private ComboBox cboRequestBloodGroup;
        private Button btnSubmitRequest;
        private DataGridView dgvRequestHistory;

        // Navigation buttons
        private Button btnProfile, btnDonation, btnRequests, btnLogout;

        public UserPortalForm(string user, string connStr)
        {
            username = user;
            connectionString = connStr;
            this.Text = $"Blood Bank System - Welcome {username}";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            InitializeUI();
            LoadDonorProfile();
        }

        private void InitializeUI()
        {
            // Navigation buttons
            btnProfile = new Button { Text = "My Profile", Location = new Point(20, 30), Size = new Size(150, 35) };
            btnProfile.Click += (s, e) => ShowPanel(pnlProfile);

            btnDonation = new Button { Text = "Donation", Location = new Point(20, 80), Size = new Size(150, 35) };
            btnDonation.Click += (s, e) => { ShowPanel(pnlDonation); LoadDonationHistory(); };

            btnRequests = new Button { Text = "Blood Request", Location = new Point(20, 130), Size = new Size(150, 35) };
            btnRequests.Click += (s, e) => { ShowPanel(pnlRequest); LoadRequestHistory(); };

            btnLogout = new Button { Text = "Logout", Location = new Point(20, 500), Size = new Size(150, 35) };
            btnLogout.Click += (s, e) => { this.Close(); Application.Restart(); };

            // ========== PROFILE PANEL ==========
            pnlProfile = new Panel { Location = new Point(190, 20), Size = new Size(680, 530), BorderStyle = BorderStyle.FixedSingle };
            Label lblProfileTitle = new Label
            {
                Text = "DONOR REGISTRATION / UPDATE",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(640, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            int x = 50, y = 70, labelW = 120, fieldW = 200;
            Label lblName = new Label { Text = "Full Name:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            txtName = new TextBox { Location = new Point(x + labelW, y), Size = new Size(fieldW, 25) };
            y += 40;
            Label lblBloodGroup = new Label { Text = "Blood Group:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            cboBloodGroup = new ComboBox { Location = new Point(x + labelW, y), Size = new Size(100, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            cboBloodGroup.Items.AddRange(new object[] { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" });
            y += 40;
            Label lblGender = new Label { Text = "Gender:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            cboGender = new ComboBox { Location = new Point(x + labelW, y), Size = new Size(100, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            cboGender.Items.AddRange(new object[] { "Male", "Female", "Other" });
            y += 40;
            Label lblAge = new Label { Text = "Age:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            txtAge = new TextBox { Location = new Point(x + labelW, y), Size = new Size(80, 25) };
            y += 40;
            Label lblPhone = new Label { Text = "Phone:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            txtPhone = new TextBox { Location = new Point(x + labelW, y), Size = new Size(fieldW, 25) };
            y += 40;
            Label lblAddress = new Label { Text = "Address:", Location = new Point(x, y), Size = new Size(labelW, 25) };
            txtAddress = new TextBox { Location = new Point(x + labelW, y), Size = new Size(fieldW, 60), Multiline = true };
            y += 80;
            btnRegister = new Button { Text = "Register", Location = new Point(x + labelW, y), Size = new Size(100, 35) };
            btnRegister.Click += BtnRegister_Click;
            btnUpdateProfile = new Button { Text = "Update Profile", Location = new Point(x + labelW + 120, y), Size = new Size(120, 35) };
            btnUpdateProfile.Click += BtnUpdateProfile_Click;

            pnlProfile.Controls.AddRange(new Control[] {
                lblProfileTitle, lblName, txtName, lblBloodGroup, cboBloodGroup,
                lblGender, cboGender, lblAge, txtAge, lblPhone, txtPhone,
                lblAddress, txtAddress, btnRegister, btnUpdateProfile
            });

            // ========== DONATION PANEL ==========
            pnlDonation = new Panel { Location = new Point(190, 20), Size = new Size(680, 530), BorderStyle = BorderStyle.FixedSingle, Visible = false };
            Label lblDonationTitle = new Label
            {
                Text = "RECORD DONATION",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(640, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label lblDonorName = new Label { Text = "Donor Name:", Location = new Point(50, 70), Size = new Size(100, 25) };
            TextBox txtDonorName = new TextBox { Location = new Point(160, 70), Size = new Size(200, 25), ReadOnly = true, Text = username };

            Label lblDonationDate = new Label { Text = "Donation Date:", Location = new Point(50, 120), Size = new Size(100, 25) };
            txtDonationDate = new TextBox { Location = new Point(160, 120), Size = new Size(120, 25), Text = DateTime.Now.ToString("yyyy-MM-dd") };

            Label lblUnits = new Label { Text = "Units (1 unit = 450ml):", Location = new Point(50, 170), Size = new Size(150, 25) };
            txtDonationUnits = new TextBox { Location = new Point(210, 170), Size = new Size(80, 25) };

            btnSubmitDonation = new Button { Text = "Submit Donation", Location = new Point(160, 220), Size = new Size(150, 35) };
            btnSubmitDonation.Click += BtnSubmitDonation_Click;

            Label lblHistory = new Label
            {
                Text = "MY DONATION HISTORY",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(20, 280),
                Size = new Size(640, 25)
            };
            dgvDonationHistory = new DataGridView
            {
                Location = new Point(20, 310),
                Size = new Size(640, 190),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };

            pnlDonation.Controls.AddRange(new Control[] {
                lblDonationTitle, lblDonorName, txtDonorName, lblDonationDate, txtDonationDate,
                lblUnits, txtDonationUnits, btnSubmitDonation, lblHistory, dgvDonationHistory
            });

            // ========== BLOOD REQUEST PANEL ==========
            pnlRequest = new Panel { Location = new Point(190, 20), Size = new Size(680, 530), BorderStyle = BorderStyle.FixedSingle, Visible = false };
            Label lblRequestTitle = new Label
            {
                Text = "REQUEST BLOOD",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(640, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            int rx = 50, ry = 70;
            Label lblPatient = new Label { Text = "Patient Name:", Location = new Point(rx, ry), Size = new Size(110, 25) };
            txtPatientName = new TextBox { Location = new Point(rx + 120, ry), Size = new Size(200, 25) };
            ry += 45;
            Label lblReqBloodGroup = new Label { Text = "Blood Group Needed:", Location = new Point(rx, ry), Size = new Size(130, 25) };
            cboRequestBloodGroup = new ComboBox { Location = new Point(rx + 140, ry), Size = new Size(100, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            cboRequestBloodGroup.Items.AddRange(new object[] { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" });
            ry += 45;
            Label lblReqUnits = new Label { Text = "Units Required:", Location = new Point(rx, ry), Size = new Size(110, 25) };
            txtRequestUnits = new TextBox { Location = new Point(rx + 120, ry), Size = new Size(80, 25) };
            ry += 45;
            Label lblHospital = new Label { Text = "Hospital Name:", Location = new Point(rx, ry), Size = new Size(110, 25) };
            txtHospitalName = new TextBox { Location = new Point(rx + 120, ry), Size = new Size(250, 25) };
            ry += 45;
            Label lblReqDate = new Label { Text = "Request Date:", Location = new Point(rx, ry), Size = new Size(110, 25) };
            txtRequestDate = new TextBox { Location = new Point(rx + 120, ry), Size = new Size(120, 25), ReadOnly = true, Text = DateTime.Now.ToString("yyyy-MM-dd") };

            btnSubmitRequest = new Button { Text = "Submit Request", Location = new Point(rx + 120, ry + 50), Size = new Size(150, 35) };
            btnSubmitRequest.Click += BtnSubmitRequest_Click;

            Label lblReqHistory = new Label
            {
                Text = "MY REQUEST HISTORY",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(20, ry + 110),
                Size = new Size(640, 25)
            };
            dgvRequestHistory = new DataGridView
            {
                Location = new Point(20, ry + 140),
                Size = new Size(640, 180),
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };

            pnlRequest.Controls.AddRange(new Control[] {
                lblRequestTitle, lblPatient, txtPatientName, lblReqBloodGroup, cboRequestBloodGroup,
                lblReqUnits, txtRequestUnits, lblHospital, txtHospitalName, lblReqDate, txtRequestDate,
                btnSubmitRequest, lblReqHistory, dgvRequestHistory
            });

            // Add everything to form
            this.Controls.Add(btnProfile);
            this.Controls.Add(btnDonation);
            this.Controls.Add(btnRequests);
            this.Controls.Add(btnLogout);
            this.Controls.Add(pnlProfile);
            this.Controls.Add(pnlDonation);
            this.Controls.Add(pnlRequest);
        }

        private void ShowPanel(Panel panel)
        {
            pnlProfile.Visible = false;
            pnlDonation.Visible = false;
            pnlRequest.Visible = false;
            panel.Visible = true;
        }

        private void LoadDonorProfile()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT DonorID, FullName, BloodGroup, Gender, DATEDIFF(YEAR, DateOfBirth, GETDATE()) AS Age, Phone, Address FROM Donors WHERE FullName = @name";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", username);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            donorId = reader.GetInt32(0);
                            txtName.Text = reader["FullName"].ToString();
                            cboBloodGroup.Text = reader["BloodGroup"].ToString();
                            cboGender.Text = reader["Gender"].ToString();
                            txtAge.Text = reader["Age"].ToString();
                            txtPhone.Text = reader["Phone"].ToString();
                            txtAddress.Text = reader["Address"].ToString();
                            btnRegister.Enabled = false;
                            btnUpdateProfile.Enabled = true;
                        }
                        else
                        {
                            donorId = -1;
                            txtName.Text = username;
                            cboBloodGroup.SelectedIndex = -1;
                            cboGender.SelectedIndex = -1;
                            txtAge.Text = "";
                            txtPhone.Text = "";
                            txtAddress.Text = "";
                            btnRegister.Enabled = true;
                            btnUpdateProfile.Enabled = false;
                        }
                    }
                }
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            if (!ValidateProfile()) return;
            DateTime dob = DateTime.Now.AddYears(-int.Parse(txtAge.Text));
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"INSERT INTO Donors (FullName, BloodGroup, DateOfBirth, Gender, Phone, Address, RegistrationDate) 
                                 VALUES (@name, @bg, @dob, @gender, @phone, @address, GETDATE())";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@bg", cboBloodGroup.Text);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@gender", cboGender.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
            }
            LoadDonorProfile();
        }

        private void BtnUpdateProfile_Click(object sender, EventArgs e)
        {
            if (donorId == -1) { MessageBox.Show("Please register first."); return; }
            if (!ValidateProfile()) return;
            DateTime dob = DateTime.Now.AddYears(-int.Parse(txtAge.Text));
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"UPDATE Donors SET BloodGroup=@bg, DateOfBirth=@dob, Gender=@gender, Phone=@phone, Address=@address WHERE DonorID=@id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@bg", cboBloodGroup.Text);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@gender", cboGender.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", donorId);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadDonorProfile();
        }

        private bool ValidateProfile()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(cboBloodGroup.Text) ||
                string.IsNullOrWhiteSpace(cboGender.Text) || !int.TryParse(txtAge.Text, out int age) || age < 16 || age > 70 ||
                string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Please fill all fields correctly (Age between 16-70).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void LoadDonationHistory()
        {
            if (donorId == -1) return;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT DonationDate, BloodGroup, Units FROM Donations WHERE DonorID = @id ORDER BY DonationDate DESC";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", donorId);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvDonationHistory.DataSource = dt;
                }
            }
        }

        private void BtnSubmitDonation_Click(object sender, EventArgs e)
        {
            if (donorId == -1)
            {
                MessageBox.Show("Please complete your donor registration first.", "Not Registered", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!int.TryParse(txtDonationUnits.Text, out int units) || units <= 0)
            {
                MessageBox.Show("Enter valid number of units (positive integer).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!DateTime.TryParse(txtDonationDate.Text, out DateTime donationDate))
            {
                MessageBox.Show("Invalid date format. Use YYYY-MM-DD.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string bloodGroup = cboBloodGroup.Text;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (var transaction = con.BeginTransaction())
                    {
                        string insertDonation = "INSERT INTO Donations (DonorID, DonationDate, BloodGroup, Units) VALUES (@did, @date, @bg, @units)";
                        using (SqlCommand cmd = new SqlCommand(insertDonation, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@did", donorId);
                            cmd.Parameters.AddWithValue("@date", donationDate);
                            cmd.Parameters.AddWithValue("@bg", bloodGroup);
                            cmd.Parameters.AddWithValue("@units", units);
                            cmd.ExecuteNonQuery();
                        }
                        string updateInv = "UPDATE Inventory SET AvailableUnits = AvailableUnits + @units, LastUpdated = GETDATE() WHERE BloodGroup = @bg";
                        using (SqlCommand cmd = new SqlCommand(updateInv, con, transaction))
                        {
                            cmd.Parameters.AddWithValue("@units", units);
                            cmd.Parameters.AddWithValue("@bg", bloodGroup);
                            if (cmd.ExecuteNonQuery() == 0)
                            {
                                string insertInv = "INSERT INTO Inventory (BloodGroup, AvailableUnits, LastUpdated) VALUES (@bg, @units, GETDATE())";
                                using (SqlCommand cmd2 = new SqlCommand(insertInv, con, transaction))
                                {
                                    cmd2.Parameters.AddWithValue("@bg", bloodGroup);
                                    cmd2.Parameters.AddWithValue("@units", units);
                                    cmd2.ExecuteNonQuery();
                                }
                            }
                        }
                        transaction.Commit();
                    }
                }
                txtDonationUnits.Clear();
                LoadDonationHistory();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error recording donation: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRequestHistory()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = @"SELECT BloodGroup, Units, HospitalName, RequestDate, Status FROM BloodRequests 
                                 WHERE RequesterName = @name ORDER BY RequestDate DESC";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", username);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvRequestHistory.DataSource = dt;
                }
            }
        }

        private void BtnSubmitRequest_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPatientName.Text) || string.IsNullOrWhiteSpace(cboRequestBloodGroup.Text) ||
                !int.TryParse(txtRequestUnits.Text, out int units) || units <= 0 ||
                string.IsNullOrWhiteSpace(txtHospitalName.Text))
            {
                MessageBox.Show("Please fill all fields correctly.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!DateTime.TryParse(txtRequestDate.Text, out DateTime reqDate))
                reqDate = DateTime.Now;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    string query = @"INSERT INTO BloodRequests (RequesterName, PatientName, BloodGroup, Units, HospitalName, RequestDate, Status) 
                                     VALUES (@reqName, @patName, @bg, @units, @hospital, @date, 'Pending')";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@reqName", username);
                        cmd.Parameters.AddWithValue("@patName", txtPatientName.Text.Trim());
                        cmd.Parameters.AddWithValue("@bg", cboRequestBloodGroup.Text);
                        cmd.Parameters.AddWithValue("@units", units);
                        cmd.Parameters.AddWithValue("@hospital", txtHospitalName.Text.Trim());
                        cmd.Parameters.AddWithValue("@date", reqDate);
                        cmd.ExecuteNonQuery();
                    }
                }
                txtPatientName.Clear();
                txtRequestUnits.Clear();
                txtHospitalName.Clear();
                LoadRequestHistory();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting request: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
